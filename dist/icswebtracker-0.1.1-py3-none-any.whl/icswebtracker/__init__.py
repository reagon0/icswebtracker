"""Django app for tracking website visitors without JavaScript."""

__version__ = "0.1.1"